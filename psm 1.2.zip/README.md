Author: Meleketos / Daniel Wieźlak / Daniel Wiezlak / DanielWiezlak
Source: wikipedia
Version: 1.2

CO NOWEGO:
Dodano:
- Możliwość pisania tekstu przy znakach B5 i B7