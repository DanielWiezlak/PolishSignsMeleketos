Author: Meleketos / Daniel Wieźlak / Daniel Wiezlak / DanielWiezlak
Source: wikipedia
Version: 1.1