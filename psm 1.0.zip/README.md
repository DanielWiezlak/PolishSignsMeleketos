Author: Meleketos / Daniel Wieźlak / Daniel Wiezlak / DanielWiezlak
Source: wikipedia